package com.trg.chatbot;

import org.junit.Test;
import junit.framework.Assert;

public class MetrosTest {

  @Test
  public void test_true() {
    final Metros metro=new Metros();
    final boolean met=metro.isMetro("bangalore");
    Assert.assertEquals(true, met);
    final boolean met1=metro.isMetro("delhi");
    Assert.assertEquals(true, met1);
    final boolean met2=metro.isMetro("bengaluru");
    Assert.assertEquals(true, met2);
    final boolean met3=metro.isMetro("mumbai");
    Assert.assertEquals(true, met3);
    final boolean met4=metro.isMetro("kolkatha");
    Assert.assertEquals(true, met4);
    final boolean met5=metro.isMetro("pune");
    Assert.assertEquals(true, met5);
    final boolean met6=metro.isMetro("hyderabad");
    Assert.assertEquals(true, met6);
    final boolean met7=metro.isMetro("BANGALORE");
    Assert.assertEquals(true, met7);
    final boolean met8=metro.isMetro("PUNE");
    Assert.assertEquals(true, met8);
    final boolean met9=metro.isMetro("Pune");
    Assert.assertEquals(true, met9);
  }


  @Test
  public void test_false() {
    final Metros metro=new Metros();
    final boolean met=metro.isMetro("bangalore45");
    Assert.assertEquals(false, met);
    final boolean met1=metro.isMetro("newdelhi");
    Assert.assertEquals(false, met1);
    final boolean met2=metro.isMetro("punee");
    Assert.assertEquals(false, met2);
    final boolean met3=metro.isMetro("bengalore");
    Assert.assertEquals(false, met3);
    final boolean met4=metro.isMetro("COLKATTA");
    Assert.assertEquals(false, met4);
    final boolean met5=metro.isMetro("HAIDERABAD");
    Assert.assertEquals(false, met5);
  }
}