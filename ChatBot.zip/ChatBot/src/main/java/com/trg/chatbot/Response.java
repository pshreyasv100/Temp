package com.trg.chatbot;

public class Response {
  private String content;


  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

}
