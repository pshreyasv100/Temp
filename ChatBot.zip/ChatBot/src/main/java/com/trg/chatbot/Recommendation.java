package com.trg.chatbot;

import java.util.List;

public class Recommendation {

  List<String> products;

  public List<String> getProducts() {
    return products;
  }

  public void setProducts(List<String> products) {
    this.products = products;
  }

}
