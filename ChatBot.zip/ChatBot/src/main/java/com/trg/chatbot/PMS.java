package com.trg.chatbot;

public class PMS {
  String type;
  String model;
  String screensize;
  String touch;
  String masimorainbow;
  String philipsSpo2;
  String cardiacoutput;
  String maxNoOfWaveforms;
  String leadECG12;

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getModel() {
    return model;
  }

  public void setModel(String model) {
    this.model = model;
  }

  public String getScreensize() {
    return screensize;
  }

  public void setScreensize(String screensize) {
    this.screensize = screensize;
  }

  public String getTouch() {
    return touch;
  }

  public void setTouch(String touch) {
    this.touch = touch;
  }

  public String getMasimorainbow() {
    return masimorainbow;
  }

  public void setMasimorainbow(String masimorainbow) {
    this.masimorainbow = masimorainbow;
  }

  public String getPhilipsSpo2() {
    return philipsSpo2;
  }

  public void setPhilipsSpo2(String philipsSpo2) {
    this.philipsSpo2 = philipsSpo2;
  }

  public String getCardiacoutput() {
    return cardiacoutput;
  }

  public void setCardiacoutput(String cardiacoutput) {
    this.cardiacoutput = cardiacoutput;
  }

  public String getMaxNoOfWaveforms() {
    return maxNoOfWaveforms;
  }

  public void setMaxNoOfWaveforms(String maxNoOfWaveforms) {
    this.maxNoOfWaveforms = maxNoOfWaveforms;
  }

  public String getLeadECG12() {
    return leadECG12;
  }

  public void setLeadECG12(String leadECG12) {
    this.leadECG12 = leadECG12;
  }

}
