# ChatBot

The idea is to create a chatbot that will help it’s users to arrive at a suggestion on the available Philips products that is suitable for their requirements .
The products those come under the scope of this chatbot are Patient Monitoring Sytems  
. The User who will be seeking help of this chatbot will be a clinical person who can understand the medical terminologies related to Patient Monitoring Systems.
The  requirements of that will come as input to the chatbot will be dependent of the needs of the user and the organisation/hospital which he/she represents.

The API is documented using Swagger . In order to check the working of API
  1. clone this repository and import into a maven project
  2. add maven dependency for swagger in the 'pom.xml' file and update maven project
  3. run the project in eclipse IDE 
  4. access Swagger in web browser using this link : ""
  
  The gating thresholds that is being set are 
    1. Number of compilation errors =0
    2. Number of dupliactes for 3 lines = 0
    3. Upper bound for cyclomatic complexity = 3
    4. Coverage of Unit tests = 80 %
